# 🐳 Docker Setup - Step by Step Guide

## Prerequisites
- ✅ Ubuntu 20.04+ VPS (2GB RAM minimum)
- ✅ Root/sudo access
- ✅ SSH access to VPS

---

## 📝 STEP 1: Connect to Your VPS

```bash
ssh root@your-vps-ip
```

Replace `your-vps-ip` with your actual VPS IP address.

**Example:**
```bash
ssh root@123.45.67.89
```

---

## 📦 STEP 2: Install Docker

```bash
# Update system
apt update && apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com | sh

# Start Docker service
systemctl enable docker
systemctl start docker

# Verify installation
docker --version
```

**Expected output:**
```
Docker version 24.0.7, build afdd53b
```

---

## 📦 STEP 3: Install Docker Compose

```bash
# Download Docker Compose
curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose

# Make it executable
chmod +x /usr/local/bin/docker-compose

# Verify installation
docker-compose --version
```

**Expected output:**
```
Docker Compose version v2.24.1
```

---

## 📂 STEP 4: Upload Project Files

**Option A: From your computer**

```bash
# On your computer (not VPS)
scp instagram-reel-viewer.tar.gz root@your-vps-ip:/root/
```

**Option B: Download directly on VPS**

```bash
# If you have the file hosted somewhere
cd /root
wget https://your-file-host.com/instagram-reel-viewer.tar.gz
```

---

## 📁 STEP 5: Extract Files

```bash
cd /root

# Extract
tar -xzf instagram-reel-viewer.tar.gz

# Enter directory
cd instagram-reel-viewer

# Check files
ls -la
```

**You should see:**
```
bot.py
downloader.js
server.js
docker-compose.yml
Dockerfile
package.json
requirements.txt
.env.example
README.md
SETUP_GUIDE.md
```

---

## 🤖 STEP 6: Create Telegram Bot

### 6.1: Create Bot with BotFather

1. Open Telegram
2. Search: **@BotFather**
3. Send: `/newbot`
4. Bot name: `My Reels Bot` (or any name)
5. Username: `my_reels_viewer_bot` (must be unique, add numbers if taken)
6. **COPY THE TOKEN**

**Example token:**
```
1234567890:ABCdefGHIjklMNOpqrsTUVwxyz-1234567
```

### 6.2: Get Your Telegram User ID

1. Search: **@userinfobot**
2. Send: `/start`
3. **COPY YOUR ID**

**Example:**
```
Id: 123456789
```

### 6.3: Get API Credentials

1. Go to: https://my.telegram.org
2. Login with your phone number
3. Click **"API development tools"**
4. Fill in:
   - App title: `Reels Viewer`
   - Short name: `reels`
   - Platform: `Other`
5. Click **Create application**
6. **COPY:**
   - `api_id` (example: 12345678)
   - `api_hash` (example: abcdef1234567890abcdef1234567890)

---

## ⚙️ STEP 7: Configure Environment

```bash
# Create .env file from example
cp .env.example .env

# Edit with nano
nano .env
```

**Fill in your credentials:**

```env
# Telegram Bot Configuration
TELEGRAM_BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrsTUVwxyz-1234567
TELEGRAM_API_ID=12345678
TELEGRAM_API_HASH=abcdef1234567890abcdef1234567890
ADMIN_TELEGRAM_ID=123456789

# Server Configuration
PORT=3000
HOST=0.0.0.0

# Instagram Settings
MIN_CACHE_SIZE=50
MAX_CACHE_SIZE=100
VIDEO_QUALITY=1080p
AUTO_DELETE_MINUTES=10

# Proxy Settings (optional)
PROXY_ENABLED=false
```

**Save and exit:**
- Press `Ctrl + X`
- Press `Y`
- Press `Enter`

---

## 🚀 STEP 8: Build and Start Docker Containers

```bash
# Make sure you're in the project directory
cd /root/instagram-reel-viewer

# Build and start all services
docker-compose up -d
```

**This will:**
1. Build Docker images (2-3 minutes)
2. Start 3 containers:
   - `web` (web server on port 3000)
   - `downloader` (background downloader)
   - `bot` (Telegram bot)

**Expected output:**
```
Creating network "instagram-reel-viewer_default" with the default driver
Creating instagram-reel-viewer_web_1        ... done
Creating instagram-reel-viewer_downloader_1 ... done
Creating instagram-reel-viewer_bot_1        ... done
```

---

## ✅ STEP 9: Check Status

```bash
# View running containers
docker-compose ps
```

**Expected output:**
```
NAME                              STATUS
instagram-reel-viewer-web-1       Up 30 seconds
instagram-reel-viewer-downloader-1 Up 30 seconds
instagram-reel-viewer-bot-1       Up 30 seconds
```

**All should show "Up"**

---

## 📱 STEP 10: Test Telegram Bot

1. Open Telegram
2. Search for your bot: `@my_reels_viewer_bot`
3. Send: `/start`

**Expected response:**
```
🤖 Instagram Reels Viewer Bot

Account Management:
/accounts - List all accounts
/add_account <username> <password> - Add account
...
```

**If bot responds = SUCCESS!** ✅

---

## 👤 STEP 11: Add Instagram Accounts

```
/add_account your_ig_username your_ig_password
```

**Scenario 1: No 2FA**
```
You: /add_account john_doe mypass123
Bot: 🔄 Attempting login for john_doe...
Bot: ✅ Account Added Successfully!
     Username: john_doe
     Status: Active
```

**Scenario 2: 2FA Required**
```
You: /add_account john_doe mypass123
Bot: 🔐 2FA Required for john_doe
     Enter the 6-digit code:
You: 123456
Bot: ✅ 2FA Verified! Account added.
```

**Scenario 3: Instagram Challenge**
```
You: /add_account john_doe mypass123
Bot: ⚠️ Instagram Challenge Required
     Enter the verification code:
You: 987654
Bot: ✅ Challenge Passed! Account added.
```

**Add 2-3 accounts for best results.**

---

## 🌐 STEP 12: Access Website

### Local Testing:
```
http://YOUR_VPS_IP:3000
```

**Example:**
```
http://123.45.67.89:3000
```

**Open on your phone and start scrolling!**

---

## 🔥 STEP 13: Configure Firewall (Important!)

```bash
# Allow necessary ports
ufw allow 22    # SSH
ufw allow 80    # HTTP
ufw allow 443   # HTTPS
ufw allow 3000  # Web server

# Enable firewall
ufw enable

# Check status
ufw status
```

---

## 🔍 STEP 14: View Logs (Optional)

```bash
# View all logs
docker-compose logs

# Follow logs in real-time
docker-compose logs -f

# View specific service logs
docker-compose logs bot
docker-compose logs downloader
docker-compose logs web

# Last 50 lines
docker-compose logs --tail=50
```

---

## 📊 STEP 15: Check System Stats

In Telegram bot:
```
/stats
```

**Expected response:**
```
📊 System Statistics

👥 Accounts: 2/2
🎥 Videos Cached: 0 (will grow soon)
💾 Storage Used: 0.00 GB
🌐 Proxies: 0
⚙️ Proxy Status: Disabled
```

**Wait 2-5 minutes, check again:**
```
/stats
```

Videos should start appearing!

---

## 🎉 STEP 16: Test Website

1. Open `http://YOUR_IP:3000` on phone
2. First video should load automatically
3. Scroll down = next video
4. Double tap = skip
5. That's it!

**No buttons. Just pure scrolling!**

---

## 🔧 Common Docker Commands

### View containers:
```bash
docker-compose ps
```

### Restart all services:
```bash
docker-compose restart
```

### Restart specific service:
```bash
docker-compose restart bot
docker-compose restart downloader
docker-compose restart web
```

### Stop all services:
```bash
docker-compose stop
```

### Start all services:
```bash
docker-compose start
```

### Stop and remove containers:
```bash
docker-compose down
```

### Rebuild after code changes:
```bash
docker-compose up -d --build
```

### View resource usage:
```bash
docker stats
```

---

## 🐛 Troubleshooting

### Problem: Bot not responding

**Solution:**
```bash
# Check bot logs
docker-compose logs bot

# Restart bot
docker-compose restart bot

# If still not working, check .env
cat .env
```

### Problem: No videos loading

**Solution:**
```bash
# Check downloader logs
docker-compose logs downloader

# Check if videos are downloading
ls -lh videos/

# Restart downloader
docker-compose restart downloader

# Check account status in Telegram
/accounts
```

### Problem: "Cannot start service..."

**Solution:**
```bash
# Stop everything
docker-compose down

# Remove old containers
docker-compose rm -f

# Rebuild
docker-compose up -d --build
```

### Problem: Port 3000 already in use

**Solution:**
```bash
# Find what's using port 3000
lsof -i :3000

# Kill the process
kill -9 <PID>

# Or change port in .env
nano .env
# Change: PORT=3001

# Restart
docker-compose down
docker-compose up -d
```

### Problem: Instagram login fails

**Solution:**
- Use accounts 2+ months old
- Reply to bot 2FA prompts within 30 seconds
- Try: `/remove_account username` then `/add_account username password`
- Check logs: `docker-compose logs bot`

---

## 📈 Maintenance

### Update system:
```bash
cd /root/instagram-reel-viewer
docker-compose pull
docker-compose up -d --build
```

### Backup:
```bash
tar -czf backup.tar.gz sessions/ config.json .env
```

### Clear cache:
```bash
/clear_cache  # In Telegram bot
# or
rm -rf videos/*
```

### Monitor storage:
```bash
df -h
du -sh videos/
```

---

## 🌐 Production Setup (Optional)

### Setup Domain with Nginx:

```bash
# Install Nginx
apt install -y nginx

# Create config
nano /etc/nginx/sites-available/reels
```

**Paste:**
```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

**Enable:**
```bash
ln -s /etc/nginx/sites-available/reels /etc/nginx/sites-enabled/
nginx -t
systemctl restart nginx
```

**Add HTTPS:**
```bash
apt install -y certbot python3-certbot-nginx
certbot --nginx -d your-domain.com
```

Now access: `https://your-domain.com`

---

## ✅ Summary

**You've successfully:**
1. ✅ Installed Docker + Docker Compose
2. ✅ Uploaded and configured project
3. ✅ Created Telegram bot
4. ✅ Started all services with Docker
5. ✅ Added Instagram accounts (with OTP handling)
6. ✅ Accessed clean UI website

**System is now:**
- 🚀 Running 24/7
- 📥 Auto-downloading reels
- 🔐 Handling OTP/2FA via Telegram
- 🗑️ Auto-deleting old videos
- 📱 Serving clean mobile UI

**Control everything via Telegram bot!**

---

## 🆘 Need Help?

**Check logs:**
```bash
docker-compose logs -f
```

**Restart everything:**
```bash
docker-compose restart
```

**Start fresh:**
```bash
docker-compose down
docker-compose up -d
```

**Contact:** Send issues in this chat!

---

🎉 **ENJOY YOUR CLEAN REELS VIEWER!**
