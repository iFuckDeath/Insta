# 🚀 Instagram Reels Viewer - Complete Setup Guide

## 📋 Table of Contents
1. [Prerequisites](#prerequisites)
2. [Quick Start (VPS Setup)](#quick-start-vps-setup)
3. [Telegram Bot Setup](#telegram-bot-setup)
4. [Configuration](#configuration)
5. [Running the System](#running-the-system)
6. [Using the Bot](#using-the-bot)
7. [Troubleshooting](#troubleshooting)

---

## Prerequisites

### Required:
- ✅ VPS with Ubuntu 20.04+ (2GB RAM minimum)
- ✅ Domain name (optional but recommended)
- ✅ Telegram account
- ✅ 2-3 Instagram accounts (for downloading)

### Tools Needed:
- Node.js 18+
- Python 3.8+
- Docker (optional, but easier)

---

## Quick Start (VPS Setup)

### Step 1: Connect to Your VPS

```bash
ssh root@your-vps-ip
```

### Step 2: Install Dependencies

```bash
# Update system
apt update && apt upgrade -y

# Install Node.js 18
curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
apt install -y nodejs

# Install Python and pip
apt install -y python3 python3-pip

# Install Docker (optional)
curl -fsSL https://get.docker.com | sh
```

### Step 3: Upload Project Files

**Option A: Clone from your location**
```bash
cd /root
# Upload the instagram-reel-viewer folder to /root/instagram-reel-viewer
```

**Option B: Copy files**
```bash
scp -r instagram-reel-viewer root@your-vps-ip:/root/
```

### Step 4: Install Project Dependencies

```bash
cd /root/instagram-reel-viewer

# Install Node.js dependencies
npm install

# Install Python dependencies
pip3 install -r requirements.txt
```

---

## Telegram Bot Setup

### Step 1: Create Telegram Bot

1. Open Telegram and search for **@BotFather**
2. Send `/newbot`
3. Choose a name: `My Reels Bot`
4. Choose username: `my_reels_viewer_bot` (must be unique)
5. **Copy the bot token** (looks like: `1234567890:ABCdefGHIjklMNOpqrsTUVwxyz`)

### Step 2: Get Your Telegram User ID

1. Search for **@userinfobot** on Telegram
2. Send `/start`
3. **Copy your user ID** (example: `123456789`)

### Step 3: Get Telegram API Credentials

1. Go to: https://my.telegram.org
2. Login with your phone number
3. Click "API development tools"
4. Create a new application:
   - App title: `Reels Viewer`
   - Short name: `reels`
   - Platform: Other
5. **Copy `api_id` and `api_hash`**

### Step 4: Configure Environment

```bash
cd /root/instagram-reel-viewer
cp .env.example .env
nano .env
```

Fill in your credentials:

```env
# Telegram Bot Configuration
TELEGRAM_BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrsTUVwxyz
TELEGRAM_API_ID=12345678
TELEGRAM_API_HASH=abcdef1234567890abcdef1234567890
ADMIN_TELEGRAM_ID=123456789

# Server Configuration
PORT=3000
HOST=0.0.0.0

# Instagram Settings
MIN_CACHE_SIZE=50
MAX_CACHE_SIZE=100
VIDEO_QUALITY=1080p
AUTO_DELETE_MINUTES=10

# Proxy Settings (optional)
PROXY_ENABLED=false
```

**Save and exit** (Ctrl+X, then Y, then Enter)

---

## Configuration

Your `.env` file is now ready! The system will:
- Keep 50-100 videos cached
- Auto-delete videos after 10 minutes
- Download 1080p quality
- Only accept commands from your Telegram ID

---

## Running the System

### Method 1: Docker (Recommended - Easiest)

```bash
cd /root/instagram-reel-viewer

# Start all services
docker-compose up -d

# Check status
docker-compose ps

# View logs
docker-compose logs -f
```

**Services running:**
- Web server on port 3000
- Downloader (background)
- Telegram bot

### Method 2: Manual (Without Docker)

Open 3 terminal windows/screens:

**Terminal 1: Web Server**
```bash
cd /root/instagram-reel-viewer
npm start
```

**Terminal 2: Downloader**
```bash
cd /root/instagram-reel-viewer
node downloader.js
```

**Terminal 3: Telegram Bot**
```bash
cd /root/instagram-reel-viewer
python3 bot.py
```

### Method 3: PM2 (Production - Best for long-term)

```bash
# Install PM2
npm install -g pm2

# Start services
pm2 start server.js --name "reels-web"
pm2 start downloader.js --name "reels-downloader"
pm2 start bot.py --name "reels-bot" --interpreter python3

# Save configuration
pm2 save
pm2 startup

# View status
pm2 status

# View logs
pm2 logs
```

---

## Using the Bot

### Step 1: Start Your Bot

Open Telegram and find your bot (search for `@my_reels_viewer_bot`)

Send: `/start`

You'll see the command list!

### Step 2: Add Instagram Accounts

```
/add_account your_ig_username your_ig_password
```

**The bot will handle 2FA/OTP automatically:**

**Scenario A: No 2FA**
```
You: /add_account john_doe mypassword123
Bot: ✅ Account added successfully!
```

**Scenario B: 2FA Required**
```
You: /add_account john_doe mypassword123
Bot: 🔐 2FA Required
     Enter the 6-digit code:
You: 123456
Bot: ✅ 2FA Verified! Account added.
```

**Scenario C: Instagram Challenge**
```
You: /add_account john_doe mypassword123
Bot: ⚠️ Instagram challenge detected
     Enter verification code:
You: 987654
Bot: ✅ Challenge passed! Account added.
```

### Step 3: Add More Accounts (Optional)

```
/add_account account2_user password2
/add_account account3_user password3
```

### Step 4: Check Status

```
/stats
```

Output:
```
📊 System Statistics

👥 Accounts: 3/3
🎥 Videos Cached: 87
💾 Storage Used: 3.2 GB
🌐 Proxies: 0
⚙️ Proxy Status: Disabled
```

### Step 5: Add Proxies (Optional)

```
/add_proxy http://user:pass@proxy-ip:port
/enable_proxy
```

---

## Access Your Website

### Local Access (Testing)
```
http://your-vps-ip:3000
```

### With Domain (Production)

**Setup Nginx reverse proxy:**

```bash
# Install Nginx
apt install -y nginx

# Create config
nano /etc/nginx/sites-available/reels
```

Paste this configuration:

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable and restart:

```bash
ln -s /etc/nginx/sites-available/reels /etc/nginx/sites-enabled/
nginx -t
systemctl restart nginx
```

**Enable HTTPS (recommended):**

```bash
apt install -y certbot python3-certbot-nginx
certbot --nginx -d your-domain.com
```

Now visit: `https://your-domain.com`

---

## Bot Commands Reference

### Account Management
```
/accounts                        - List all Instagram accounts
/add_account <user> <pass>       - Add new account (handles OTP)
/remove_account <username>       - Remove account
/test_account <username>         - Test account login
```

### Proxy Management
```
/proxies                         - List all proxies
/add_proxy <url>                 - Add proxy
/remove_proxy <id>               - Remove proxy
/enable_proxy                    - Enable proxy rotation
/disable_proxy                   - Disable proxies
```

### System Control
```
/stats                           - View system statistics
/clear_cache                     - Delete all cached videos
/logs                            - View recent logs (coming soon)
```

### Settings
```
/set_quality <720p|1080p>        - Video quality preference
/set_cache <min> <max>           - Cache size limits
```

---

## Troubleshooting

### Problem: Bot doesn't respond

**Solution:**
```bash
# Check if bot is running
pm2 status
# or
docker-compose ps

# Restart bot
pm2 restart reels-bot
# or
docker-compose restart bot

# Check logs
pm2 logs reels-bot
# or
docker-compose logs bot
```

### Problem: Instagram login fails

**Solution:**
- Use aged Instagram accounts (2+ months old)
- Don't add too many accounts at once (1-2 per hour)
- If 2FA prompt appears, reply with code in Telegram
- Check bot logs for detailed error

### Problem: No videos loading on website

**Solution:**
```bash
# Check if downloader is running
pm2 list
# or
docker-compose ps

# Check video folder
ls -lh videos/

# Manually trigger download
cd /root/instagram-reel-viewer
node -e "require('./downloader').downloadReels()"
```

### Problem: Videos not playing

**Solution:**
- Try different browser
- Check browser console (F12) for errors
- Ensure port 3000 is accessible
- Check firewall: `ufw allow 3000`

### Problem: "Session expired" error

**Solution:**
```
/remove_account username
/add_account username password
```
(Re-add the account with OTP)

---

## Advanced Configuration

### Adjust Cache Settings

Edit `config.json`:
```json
{
  "settings": {
    "min_cache": 50,         // Keep minimum 50 videos
    "max_cache": 150,        // Maximum 150 videos
    "auto_delete_minutes": 5 // Delete after 5 minutes
  }
}
```

### Use Multiple Proxies

```
/add_proxy http://proxy1:port
/add_proxy http://proxy2:port
/add_proxy http://proxy3:port
/enable_proxy
```

### Monitor System

```bash
# Real-time logs
pm2 logs --lines 50

# CPU/Memory usage
pm2 monit

# Restart all services
pm2 restart all
```

---

## Security Tips

1. **Use strong passwords** for Instagram accounts
2. **Enable firewall:**
   ```bash
   ufw allow 22
   ufw allow 80
   ufw allow 443
   ufw allow 3000
   ufw enable
   ```
3. **Keep bot token secret** - never share `.env` file
4. **Use HTTPS** with Let's Encrypt (free)
5. **Regular backups:**
   ```bash
   tar -czf backup.tar.gz sessions/ config.json .env
   ```

---

## Maintenance

### Update System
```bash
cd /root/instagram-reel-viewer
git pull  # if using git
pm2 restart all
```

### Clear Old Sessions
```bash
rm -rf sessions/*.json
# Then re-add accounts via bot
```

### Monitor Storage
```bash
df -h
du -sh videos/
```

---

## Support

### Common Issues:
- Bot not responding → Check `.env` credentials
- 2FA problems → Reply to bot messages promptly
- No videos → Check Instagram accounts are active
- High storage → Reduce `max_cache` in settings

### Logs Location:
- Bot: `logs/bot.log`
- PM2: `pm2 logs`
- Docker: `docker-compose logs`

---

## 🎉 You're Done!

**Your system is now:**
- ✅ Running 24/7
- ✅ Auto-downloading reels
- ✅ Handling OTP/2FA via Telegram
- ✅ Serving clean UI
- ✅ Auto-deleting old videos

**Access your site:**
- Local: `http://your-ip:3000`
- Production: `https://your-domain.com`

**Control via Telegram bot:**
- Add accounts (with OTP support)
- Manage proxies
- View stats
- Configure settings

**Enjoy! 🚀**
