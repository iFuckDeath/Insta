// Web Server - Serves reels to users
const express = require('express');
const cors = require('cors');
const fs = require('fs-extra');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || '0.0.0.0';
const VIDEO_DIR = 'videos';

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Serve videos
app.use('/videos', express.static(VIDEO_DIR));

// API: Get list of reels
app.get('/api/reels', (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 10;
        
        // Get all video files
        const videos = fs.readdirSync(VIDEO_DIR)
            .filter(f => f.endsWith('.mp4'))
            .map(f => ({
                id: f.replace('.mp4', ''),
                url: `/videos/${f}`,
                timestamp: fs.statSync(path.join(VIDEO_DIR, f)).mtime.getTime()
            }))
            .sort((a, b) => b.timestamp - a.timestamp)
            .slice(0, limit);
        
        res.json(videos);
    } catch (error) {
        console.error('Error fetching reels:', error);
        res.status(500).json({ error: 'Failed to fetch reels' });
    }
});

// API: Delete a reel
app.delete('/api/reel/:id', (req, res) => {
    try {
        const filename = `${req.params.id}.mp4`;
        const filepath = path.join(VIDEO_DIR, filename);
        
        if (fs.existsSync(filepath)) {
            fs.unlinkSync(filepath);
            res.json({ success: true });
        } else {
            res.status(404).json({ error: 'Reel not found' });
        }
    } catch (error) {
        console.error('Error deleting reel:', error);
        res.status(500).json({ error: 'Failed to delete reel' });
    }
});

// API: Stats
app.get('/api/stats', (req, res) => {
    try {
        const videos = fs.readdirSync(VIDEO_DIR).filter(f => f.endsWith('.mp4'));
        const totalSize = videos.reduce((sum, file) => {
            return sum + fs.statSync(path.join(VIDEO_DIR, file)).size;
        }, 0);
        
        res.json({
            count: videos.length,
            totalSize: totalSize,
            sizeMB: (totalSize / (1024 * 1024)).toFixed(2)
        });
    } catch (error) {
        res.status(500).json({ error: 'Failed to get stats' });
    }
});

// Health check
app.get('/health', (req, res) => {
    res.json({ status: 'ok', timestamp: Date.now() });
});

// Start server
app.listen(PORT, HOST, () => {
    console.log(`Server running on http://${HOST}:${PORT}`);
    console.log(`Video directory: ${path.resolve(VIDEO_DIR)}`);
});
