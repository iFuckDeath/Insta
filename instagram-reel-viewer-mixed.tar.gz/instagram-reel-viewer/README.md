# 🎥 Instagram Reels Viewer

**Clean, minimalist Instagram Reels viewer with Telegram bot control**

## ✨ Features

- 🎯 **Zero UI** - Pure scroll, no buttons, no clutter
- 🤖 **Telegram Bot** - Full control via Telegram (add accounts, manage proxies, stats)
- 🔐 **Advanced OTP/2FA Handler** - Bot handles Instagram challenges automatically
- ♾️ **Infinite Scroll** - TikTok-style viewing experience
- 🔄 **Auto-Download** - Keeps 50-100 reels cached 24/7
- 🗑️ **Auto-Delete** - Removes watched videos automatically
- 🌐 **Proxy Support** - Rotate proxies to avoid rate limits
- 📱 **Mobile-First** - Optimized for phone viewing
- 🚀 **Easy Deploy** - Docker or PM2, your choice

## 🎬 Demo

**User Experience:**
1. Open website
2. Video plays instantly
3. Scroll = next reel
4. Double tap = skip
5. That's it!

**Admin Control (Telegram Bot):**
- Add/remove Instagram accounts
- Handle 2FA/OTP in Telegram chat
- Manage proxies
- View stats
- Configure settings

## 📋 Requirements

- Ubuntu 20.04+ VPS (2GB RAM minimum)
- Node.js 18+
- Python 3.8+
- Telegram account
- 2-3 Instagram accounts

## 🚀 Quick Start

### 1. Setup Bot

1. Create bot with @BotFather on Telegram
2. Get API credentials from https://my.telegram.org
3. Copy `.env.example` to `.env` and fill in credentials

### 2. Install & Run

**Docker (Easiest):**
```bash
docker-compose up -d
```

**PM2 (Production):**
```bash
npm install -g pm2
pm2 start server.js --name "reels-web"
pm2 start downloader.js --name "reels-downloader"
pm2 start bot.py --name "reels-bot" --interpreter python3
pm2 save
```

**Manual:**
```bash
npm install
pip3 install -r requirements.txt

# Terminal 1
npm start

# Terminal 2
node downloader.js

# Terminal 3
python3 bot.py
```

### 3. Add Instagram Accounts

Open your Telegram bot and send:
```
/add_account your_username your_password
```

Bot will handle 2FA/OTP automatically!

### 4. Access Website

```
http://your-vps-ip:3000
```

## 📖 Full Documentation

See [SETUP_GUIDE.md](SETUP_GUIDE.md) for complete setup instructions.

## 🤖 Bot Commands

**Account Management:**
- `/accounts` - List accounts
- `/add_account user pass` - Add account (handles OTP!)
- `/remove_account user` - Remove account

**Proxy Management:**
- `/proxies` - List proxies
- `/add_proxy http://ip:port` - Add proxy
- `/enable_proxy` / `/disable_proxy` - Toggle

**System:**
- `/stats` - System statistics
- `/clear_cache` - Delete all videos

## 🔐 Advanced OTP/2FA Handling

The bot automatically handles:
- ✅ SMS verification codes
- ✅ Email verification codes
- ✅ 2FA authenticator codes
- ✅ Instagram challenges/checkpoints
- ✅ Photo selection challenges

**How it works:**
1. You try to add account
2. Instagram asks for verification
3. Bot sends you message in Telegram
4. You reply with code
5. Bot completes login
6. Session saved (no more OTP needed!)

## 🎯 Architecture

```
┌─────────────────┐
│ Telegram Bot    │ ← You control everything here
│ (OTP Handler)   │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Downloader      │ ← Runs 24/7, downloads reels
│ (Background)    │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Video Cache     │ ← 50-100 reels always ready
│ (Auto-Delete)   │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Web Server      │ ← Clean UI, just scroll
│ (Zero UI)       │
└─────────────────┘
```

## 🛠️ Tech Stack

- **Backend:** Node.js + Express
- **Downloader:** instagram-private-api
- **Bot:** Telethon + instagrapi
- **Frontend:** Pure HTML/CSS/JS (no frameworks)
- **Deploy:** Docker / PM2

## 📊 Performance

- **Load time:** <1 second
- **Cache:** 50-100 videos
- **Storage:** ~5-10GB
- **Bandwidth:** ~1GB/hour (downloading)
- **Concurrent users:** 100+ (with 2GB RAM)

## 🔒 Security

- Bot only responds to your Telegram ID
- Instagram sessions encrypted
- Proxies optional but recommended
- Firewall configured via ufw

## 🐛 Troubleshooting

**Bot not responding?**
```bash
pm2 logs reels-bot
```

**No videos loading?**
```bash
ls -lh videos/
pm2 restart reels-downloader
```

**Instagram login fails?**
- Use aged accounts (2+ months)
- Reply to bot 2FA prompts quickly
- Try `/remove_account` then `/add_account` again

## 📄 License

MIT

## 🤝 Contributing

PRs welcome!

## ⚠️ Disclaimer

This tool is for educational purposes. Respect Instagram's Terms of Service. Use responsibly.

---

**Built with ❤️ for clean viewing experiences**
